package com.nucleus.multitenancy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.hibernate.engine.jdbc.connections.spi.AbstractMultiTenantConnectionProvider;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;



public class MultiTCProvider extends AbstractMultiTenantConnectionProvider{

	private HashMap<String, ConnectionProvider> cp=new HashMap<String, ConnectionProvider>();

	public MultiTCProvider()
	{
		 System.out.println("Creating bean of MultiTCProvider");
		 List<String> providers=new ArrayList<String>();
		 providers.add("default");
		 providers.add("db1");
		 providers.add("db2");
		 for(String p:providers)
		 {
			 cp.put(p, new MyConnectionProvider(p));
		 }

		 
	}
	@Override
	protected ConnectionProvider getAnyConnectionProvider() {
		// TODO Auto-generated method stub
		return cp.get("default");
	}

	@Override
	protected ConnectionProvider selectConnectionProvider(String arg0) {
		// TODO Auto-generated method stub
		System.out.println("Get connection for "+arg0);
		if(arg0.equals("tenant1"))
		return cp.get("db1");
		else
			return cp.get("db2");
					
	}

}
