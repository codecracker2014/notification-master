package com.nucleus.dvorak;

import javax.persistence.*;


@Entity
public class Tenant {

	  	@Id
	    private String name;

	    public void setName(String name) {
			this.name = name;
		}

		public void setSchemaName(String schemaName) {
			this.schemaName = schemaName;
		}

		@Column(nullable = false, updatable = false)
	    private String schemaName;

	    @Column(nullable = false, updatable = true)
	    private String password;

	    public Tenant() {
	    }

	    public String getName() {
	        return name;
	    }

	    public String getSchemaName() {
	        return schemaName;
	    }

	    public String getPassword() {
	        return password;
	    }

	    public void setPassword(final String password) {
	        this.password = password;
	    }
}
