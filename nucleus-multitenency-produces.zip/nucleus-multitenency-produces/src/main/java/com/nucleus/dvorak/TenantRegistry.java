package com.nucleus.dvorak;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
@Service
public class TenantRegistry {
	
	    private EntityManager entityManager;

	    private final Set<Tenant> tenants = new HashSet<>();
	    private final Map<String, EntityManagerFactory> entityManagerFactories = new HashMap<>();

	    

	    @PostConstruct
	    protected void startupTenants() {
	    	
	        final List<Tenant> tenants = loadTenantsFromDB();
	        tenants.forEach(tenant -> {
	            this.tenants.add(tenant);
	            final EntityManagerFactory emf = createEntityManagerFactory(tenant);
	            entityManagerFactories.put(tenant.getName(), emf);
	           
	        });
	        this.tenants.addAll(tenants);
	    }

	    @PreDestroy
	    protected void shutdownTenants() {
	        entityManagerFactories.forEach((tenantName, entityManagerFactory) -> entityManagerFactory.close());
	        entityManagerFactories.clear();
	        tenants.clear();
	    }

	    private List<Tenant> loadTenantsFromDB() {
	       Tenant t=new Tenant();
	       t.setPassword("g");
	       t.setName("tenant1");
	       t.setSchemaName("tenant1");
	       Tenant t1=new Tenant();
	       t1.setPassword("g");
	       t1.setName("tenant2");
	       t1.setSchemaName("tenant2");
	       List<Tenant> list=new ArrayList<Tenant>();
	       list.add(t);
	       list.add(t1);
	       return list;
	    	
	    }

	    /**
	     * Create new {@link EntityManagerFactory} using this tenant's schema.
	     * @param tenant Tenant used to retrieve schema name
	     * @return new EntityManagerFactory
	     */
	    private EntityManagerFactory createEntityManagerFactory(final Tenant tenant) {
	    	
	        final Map<String, String> props = new TreeMap<>();
	        System.out.println("creating emf for "+tenant.getName());
	        props.put("hibernate.default_schema", tenant.getSchemaName());
	        props.put("jdbc.driverClassName", "com.mysql.jdbc.Driver");
	        props.put("jdbc.url", "jdbc:mysql://localhost:3306/tenant1");
	        props.put("jdbc.username", "root");
	        props.put("jdbc.password", "gk");
	        return Persistence.createEntityManagerFactory("PersistenceUnitAdmin", props);
	    }

	    public Optional<Tenant> getTenant(final String tenantName) {
	        return tenants.stream().filter(tenant -> tenant.getName().equals(tenantName)).findFirst();
	    }

	    /**
	     * Returns EntityManagerFactory from the cache. EMF is created during tenant registration and initialization.
	     * @see #startupTenants()
	     */
	    public EntityManagerFactory getEntityManagerFactory(final String tenantName) {
	        return entityManagerFactories.get(tenantName);
	    }

}
