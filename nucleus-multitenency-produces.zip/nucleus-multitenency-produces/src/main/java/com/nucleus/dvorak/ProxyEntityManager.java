package com.nucleus.dvorak;

import java.lang.reflect.Proxy;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;

@Configuration
public class ProxyEntityManager {
	
	
	private EntityManager entityManager;
	
	@Autowired
    private TenantRegistry tenantRegistry;
	private final EntityManager proxy;
	public ProxyEntityManager()
	{
		proxy=(EntityManager)Proxy.newProxyInstance(this.getClass().getClassLoader(), new Class<?>[] { EntityManager.class },
	            (proxy, method, args) -> method.invoke(getCurrentEntityManager(), args));
	}
	@Bean
    public EntityManager getEntityManager() {
        return proxy;
    }

    private EntityManager getCurrentEntityManager() {
    	System.out.println("Hi");
        final String currentTenant = TenantHolder.getCurrentTenant();
        if (currentTenant != null) {
        	final EntityManager em = tenantRegistry.getEntityManagerFactory(currentTenant).createEntityManager();
            
            em.joinTransaction();
            return em;
        }
        return entityManager;
    }

}
