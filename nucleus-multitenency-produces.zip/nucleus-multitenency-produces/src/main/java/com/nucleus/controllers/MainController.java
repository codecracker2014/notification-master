package com.nucleus.controllers;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nucleus.dao.Dao;
import com.nucleus.dvorak.TenantHolder;
import com.nucleus.models.DemoEntity;
import com.nucleus.multitenancy.TenantService;
import com.nucleus.persistence.SpringUtils;


@Controller
public class MainController {

	
	@Autowired
	Dao dao;
	
	@RequestMapping(value="/welcome/{id}")
	public String welcome(@PathVariable String id) {
		

		System.out.println("Called with "+id);
		TenantHolder.setTenant("tenant1");
		DemoEntity d=new DemoEntity();
		d.setId("1235");
		d.setName("gk");
		dao.save(d);
		return "welcome";
	}
}
