package com.nucleus.other;

import java.sql.Connection;
import java.sql.SQLException;

import org.hibernate.engine.jdbc.connections.spi.MultiTenantConnectionProvider;

public class MultiTenantConnectionProviderImpl implements MultiTenantConnectionProvider{

	@Override
	public boolean isUnwrappableAs(Class arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public <T> T unwrap(Class<T> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Connection getAnyConnection() throws SQLException {
		// TODO Auto-generated method stub
		
		return null;
	}

	@Override
	public Connection getConnection(String arg0) throws SQLException {
		// TODO Auto-generated method stub
		System.out.println("Get connetion");
		return null;
	}

	@Override
	public void releaseAnyConnection(Connection arg0) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void releaseConnection(String arg0, Connection arg1) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean supportsAggressiveRelease() {
		// TODO Auto-generated method stub
		return false;
	}

}
